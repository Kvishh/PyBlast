﻿The font file in this archive was created using Fontstruct the free, online
font-building tool.
This font was created by “ripoof”*.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/1869845

*NOTE: “Typeface Mario World Pixel Filled” was originally cloned (copied)
from the FontStruction “Typeface Mario World Pixel Outline”
(https://fontstruct.com/fontstructions/show/1869834) by “ripoof”, which is
licensed under a Creative Commons Attribution Non-commercial No Derivatives
license (http://creativecommons.org/licenses/by-nc-nd/3.0/).

Try Fontstruct at https://fontstruct.com
It’s easy and it’s fun.

Fontstruct is copyright ©2021-2025 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
the other files from this archive, including this one.
